''' Copyright (c) 2025 ETH Zurich, Rahel Rickenbach, Bruce Lee, René Zurbrügg, Carmen Amo Alonso, Prof. Melanie N. Zeilinger, Institute for Dynamics Systems and Control.
No rights reserved. '''

import os
dir_path = os.path.dirname(os.path.abspath(''))

import sys
sys.path.append(dir_path+'/../../solver/')
from solver.SMConvexSolver import *

from scipy.io import loadmat
from scipy.linalg import expm

import cplex as cplex

import numpy as np
from casadi import *

import gym
import panda_gym
import pickle

def solver_problem_main():

    # For each task, we run three experiments and place a different block
    # in the way of the optimal trajectory

    num_samples = 5

    # select from: ('blue_cube', 'above', 0.03), ('green_cube', 'above', 0.03), ('orange_cube', 'above', 0.03), ('red_cube', 'above', 0.03)
    tasks = [
    ('red_cube', 'above', 0.03),('blue_cube', 'above', 0.03), ('green_cube', 'above', 0.03), ('orange_cube', 'above', 0.03)
    ] 
    # we chose horizon length small, since we work with a linear model for the sampling of unsafe state. 
    # to avoid linearization errors which could lead to an issue for the estimation of the rather small radi, we only alter the last state. 
    horizon = 4 
    execution_length = 34

    num_blocks = 4
    num_tasks = 4

    H_full = np.ndarray([num_tasks,num_blocks-1,num_blocks,num_blocks])
    R_full = np.ndarray([num_tasks,num_blocks-1,num_blocks])

    H_final = np.ndarray([num_tasks,num_blocks,num_blocks])
    R_final = np.ndarray([num_tasks,num_blocks])

    H_final_all_t = np.ndarray([num_blocks,num_blocks])
    R_final_all_t = np.ndarray([num_blocks])

    # load learned cost function 
    with open('multiple_best.pkl', 'rb') as f:
        params = pickle.load(f)

    Gs = params[0][0]
    

    for t in range(num_tasks):

        thetas = get_objective_weights_for_task(tasks[t])

        for b in range(num_blocks-1):

            environment = get_environment_for_task(tasks[t],b)
            env = environment[1]
            observation = environment[0]

            dx = len(observation)
            du = 3
            G = get_cost(tasks[t],dx)

            x, u, x_lin = get_receeding_horizon(env, tasks[t], horizon, execution_length, dx, du)
            print(x)
            print(u)

            # Generating sub-trajectory indices (j runs only from 5 to horizon-i to avoid inital linearization mismatch)
            # Using the full trajectory would make it computationally heavy
            inds = np.array([[0,0]])
            # uncomment this part to look at a second section of the trajectory, currently we are considering its end. 
            # for i in range(3,4):
            #     for j in range(6,10-i):
            #         inds = np.append(inds,[[j, j+i]],axis=0)

            for i in range(3,4):
                for j in range(execution_length-5,execution_length-i):
                    inds = np.append(inds,[[j, j+i]],axis=0)

            num_inds = np.shape(inds)[0]
            print('inds:',inds)
            print('num_inds:',num_inds)

            # create matrices and lists to store unsafe samples, their amount and their length
            s_sample_list = []
            us_sample_list = []
            num_us_samples_vec = np.zeros(num_inds)
            length_vec = np.zeros(num_inds)

            for i in range(num_inds-1):  #num_inds-1
                traj_x = np.transpose(x[inds[i+1,0]:inds[i+1,1]])
                traj_u = np.transpose(u[inds[i+1,0]:inds[i+1,1]])
                length = np.shape(traj_x)[1]

                samples,num_us_samples,length = return_infeasible_traj(G,num_samples, traj_x, traj_u, length, dx, du, thetas, Gs)

                s_sample_list.append(samples[0,:,:])
                us_sample_list.append(samples[1:num_us_samples+1,:,:])
                num_us_samples_vec[i] = int(num_us_samples)
                length_vec[i] = int(length)

            counterExamples = list()

            try:
                for h in range(10):
                    print('h', h)

                    sol = solver_problem_with_sample_traj(counterExamples,s_sample_list,us_sample_list,num_us_samples_vec,length_vec)
                    counterExamples = counterExamples + sol['counterExamples']
                    print(sol['solution'])
                    if sol['solution']:     # if no more counter examples then return
                        break

            finally:
                print(sol['solution'][0])
                R = np.array(sol['solution'][0])
                num_const = 4
                H = np.eye(num_const)

                total_num_us = int(np.sum(num_us_samples_vec*length_vec))
                bool_vec = sol['solution'][1]

                print(total_num_us)

                for j in range(num_const):
                    bool_sum = np.sum([bool_vec[j*total_num_us+i] for i in range(total_num_us)])
                    print(bool_sum)
                    if (bool_sum == total_num_us):
                        H[j,j] = 0

                print(R)
                print(H)
                print(b)


                H_full[t,b,:,:] = H
                R_full[t,b,:] = R

            H_final[t,:,:] = np.max(H_full[t,:,:,:],axis=0)
            R_final[t,:] = np.min(R_full[t,:,:],axis=0)

        H_final_all_t[:,:] = np.max(H_final[:,:,:],axis=0)
        R_final_all_t[:] = np.min(R_final[:,:],axis=0)

        print(H_final_all_t)
        print(R_final_all_t)

    with open('params_c','wb') as f:
        np.savez(f,H = H_final_all_t, R = R_final_all_t)

    env.close()



def solver_problem_with_sample_traj(counterExamples,s_sample_list,us_sample_list,num_us_samples_vec,length_vec):

    # Use satex solver to find unsafe region, structure of code inspired from examples on website
    numOfBooleanVars = int(np.sum(num_us_samples_vec*length_vec))

    print('numOfBooleanVars',numOfBooleanVars)
    numOfRealVars = 4
    numOfConvIFClauses = 8*numOfBooleanVars
    strategy = 'SMC'

    cores = 1

    tolerance = 1E-3
    solver = SMConvexSolver(4*numOfBooleanVars, numOfRealVars, numOfConvIFClauses,
                            maxNumberOfIterations = 10000,
                            counterExampleStrategy = strategy,
                            verbose = 'OFF',
                            profiling = 'False',
                            numberOfCores = cores,
                            slackTolerance = tolerance)

    # test problem I would like to solve looks the following
    # b1 + b2 = 1
    # b1 -> || 1 -2 || =< p
    # b1 -> || 1 -2.5 || =< p

    # other bool constraints options
    # solver.addBoolConstraint(solver.bVars[0])
    #s olver.addBoolConstraint(NOT(solver.bVars[1]))
    # for OR option see below (handling counter examples)

    # ---------- ADD PREVIOUS COUNTER EXAMPLES ----------------------------------------------------
    for counterExample in counterExamples:
        #print 'ADD CE', counterExample
        if not counterExample:
            continue
        constraint = [ NOT(solver.convIFClauses[counter]) for counter in counterExample ]
        # for counter in counterExample:
        #     print(counter)
        solver.addBoolConstraint(OR(*constraint))
    # ---------------------------------------------------------------------------------------------
    vars1 = [solver.rVars[0]]
    vars2 = [solver.rVars[1]]
    vars3 = [solver.rVars[2]]
    vars4 = [solver.rVars[3]]
    # add upper bound on radius (increase this if you want to increase safety margin)
    const1 = LPClause(np.array([[1.0]]), [0.01], [solver.rVars[0]], sense="L")
    const2 = LPClause(np.array([[1.0]]), [0.01], [solver.rVars[1]], sense="L")
    const3 = LPClause(np.array([[1.0]]), [0.01], [solver.rVars[2]], sense="L")
    const4 = LPClause(np.array([[1.0]]), [0.01], [solver.rVars[3]], sense="L")
    solver.addConvConstraint(const1)
    solver.addConvConstraint(const2)
    solver.addConvConstraint(const3)
    solver.addConvConstraint(const4)

    # add constraints from safe demonstration
    for d in range(len(s_sample_list)):
        length = np.int32(length_vec[d])
        for k in range(length):

            safe_trajectory = s_sample_list[d]

            # define center
            center1 = safe_trajectory[10:13,k]
            center2 = safe_trajectory[13:16,k]
            center3 = safe_trajectory[16:19,k]
            center4 = safe_trajectory[19:22,k]

            # get value of || center - x_k ||_2^2
            value_norm1 = np.sum((center1-safe_trajectory[:3,k])**2)
            value_norm2 = np.sum((center2-safe_trajectory[:3,k])**2)
            value_norm3 = np.sum((center3-safe_trajectory[:3,k])**2)
            value_norm4 = np.sum((center4-safe_trajectory[:3,k])**2)

            const1 = LPClause(np.array([[1.0]]), [value_norm1], [solver.rVars[0]], sense="L")
            const2 = LPClause(np.array([[1.0]]), [value_norm2], [solver.rVars[1]], sense="L")
            const3 = LPClause(np.array([[1.0]]), [value_norm3], [solver.rVars[2]], sense="L")
            const4 = LPClause(np.array([[1.0]]), [value_norm4], [solver.rVars[3]], sense="L")
            solver.addConvConstraint(const1)
            solver.addConvConstraint(const2)
            solver.addConvConstraint(const3)
            solver.addConvConstraint(const4)


    # print('num_vec',num_us_samples_vec)
    # print('length_vec',length_vec)
    # print(us_sample_list)

    # define counters
    const_counter_1 = int(0)
    const_counter_2 = numOfBooleanVars

    # then add IFClause constraints from unsafe demonstration
    for l in range(len(us_sample_list)):
        num_us = int(num_us_samples_vec[l])
        for d in range(num_us):
            length = int(length_vec[l])
            for k in range(length):

                unsafe_trajectories = us_sample_list[l]

                #define center
                center1 = unsafe_trajectories[d,10:13,k]
                center2 = unsafe_trajectories[d,13:16,k]
                center3 = unsafe_trajectories[d,16:19,k]
                center4 = unsafe_trajectories[d,19:22,k]

                # get value of || center - x_k ||_2^2
                value_norm1 = np.sum((center1-unsafe_trajectories[d,:3,k])**2)
                value_norm2 = np.sum((center2-unsafe_trajectories[d,:3,k])**2)
                value_norm3 = np.sum((center3-unsafe_trajectories[d,:3,k])**2)
                value_norm4 = np.sum((center4-unsafe_trajectories[d,:3,k])**2)

                const1_l = LPClause(np.array([[1.0]]), [value_norm1], [solver.rVars[0]], sense="L")
                const1_g = LPClause(np.array([[1.0]]), [value_norm1], [solver.rVars[0]], sense="G")
                solver.setConvIFClause(const1_l,const_counter_1+d*length+k)
                solver.setConvIFClause(const1_g,const_counter_2+d*length+k)
                solver.addBoolConstraint(IMPLIES(solver.bVars[const_counter_1+d*length+k],solver.convIFClauses[const_counter_1+d*length+k]))
                solver.addBoolConstraint(IMPLIES(NOT(solver.bVars[const_counter_1+d*length+k]),solver.convIFClauses[const_counter_2+d*length+k]))

                const2_l = LPClause(np.array([[1.0]]), [value_norm2], [solver.rVars[1]], sense="L")
                const2_g = LPClause(np.array([[1.0]]), [value_norm2], [solver.rVars[1]], sense="G")
                solver.setConvIFClause(const2_l,2*numOfBooleanVars+const_counter_1+d*length+k)
                solver.setConvIFClause(const2_g,2*numOfBooleanVars+const_counter_2+d*length+k)
                print(const_counter_1+d*length+k)
                solver.addBoolConstraint(IMPLIES(solver.bVars[1*numOfBooleanVars+const_counter_1+d*length+k],solver.convIFClauses[2*numOfBooleanVars+const_counter_1+d*length+k]))
                solver.addBoolConstraint(IMPLIES(NOT(solver.bVars[1*numOfBooleanVars+const_counter_1+d*length+k]),solver.convIFClauses[2*numOfBooleanVars+const_counter_2+d*length+k]))

                const3_l = LPClause(np.array([[1.0]]), [value_norm3], [solver.rVars[2]], sense="L")
                const3_g = LPClause(np.array([[1.0]]), [value_norm3], [solver.rVars[2]], sense="G")
                solver.setConvIFClause(const3_l,4*numOfBooleanVars+const_counter_1+d*length+k)
                solver.setConvIFClause(const3_g,4*numOfBooleanVars+const_counter_2+d*length+k)
                print(const_counter_1+d*length+k)
                solver.addBoolConstraint(IMPLIES(solver.bVars[2*numOfBooleanVars+const_counter_1+d*length+k],solver.convIFClauses[4*numOfBooleanVars+const_counter_1+d*length+k]))
                solver.addBoolConstraint(IMPLIES(NOT(solver.bVars[2*numOfBooleanVars+const_counter_1+d*length+k]),solver.convIFClauses[4*numOfBooleanVars+const_counter_2+d*length+k]))

                const4_l = LPClause(np.array([[1.0]]), [value_norm4], [solver.rVars[3]], sense="L")
                const4_g = LPClause(np.array([[1.0]]), [value_norm4], [solver.rVars[3]], sense="G")
                solver.setConvIFClause(const4_l,6*numOfBooleanVars+const_counter_1+d*length+k)
                solver.setConvIFClause(const4_g,6*numOfBooleanVars+const_counter_2+d*length+k)
                print(const_counter_1+d*length+k)
                solver.addBoolConstraint(IMPLIES(solver.bVars[3*numOfBooleanVars+const_counter_1+d*length+k],solver.convIFClauses[6*numOfBooleanVars+const_counter_1+d*length+k]))
                solver.addBoolConstraint(IMPLIES(NOT(solver.bVars[3*numOfBooleanVars+const_counter_1+d*length+k]),solver.convIFClauses[6*numOfBooleanVars+const_counter_2+d*length+k]))

            #and conclude everything with a constraint that says within each trajector one state is unsafe 
            solver.addBoolConstraint(sum([BoolVar2Int(solver.bVars[b])+BoolVar2Int(solver.bVars[1*numOfBooleanVars+b])+BoolVar2Int(solver.bVars[2*numOfBooleanVars+b])+BoolVar2Int(solver.bVars[3*numOfBooleanVars+b]) for b in range (const_counter_1+d*length,const_counter_1+(d+1)*length)]) <= (4*length-1))

        const_counter_1 = int(np.sum(num_us_samples_vec[:l+1]*length_vec[:l+1]))

        const_counter_2 = numOfBooleanVars + const_counter_1

    solution = solver.solve()

    counter_examples = solver.counterExamples
    number_counter_examples = len(counter_examples)

    if not solution:
        sol = { 'solution': [],
                'counterExamples' : counter_examples
                }
        return  sol
    else:
        sol = { 'solution': solution,
                'counterExamples' : counter_examples
                }


    return sol

def get_objective_weights_for_task(task):

    ###### This function loads the learned cost functions for the selected task from the folder ##### 
    

    if task == ('blue_cube', 'above', 0.03):
        thetas =  np.load('objective_weights/0.03_meters_above_object_one_MPC_weight.npy')
        print("thetas:", thetas)


    if task == ('green_cube', 'above', 0.03):
        thetas =  np.load('objective_weights/0.03_meters_above_object_four_MPC_weight.npy')
        print("thetas:", thetas)


    if task == ('orange_cube', 'above', 0.03):
        thetas =  np.load('objective_weights/0.03_meters_above_object_three_MPC_weight.npy')
        print("thetas:", thetas)


    if task == ('red_cube', 'above', 0.03):
        thetas =  np.load('objective_weights/0.03_meters_above_object_two_MPC_weight.npy')
        print("thetas:", thetas)

    return thetas

def get_environment_for_task(task,b):

    ###### Use this function to change initial position and block positions ##### 
    ###### in case a constraint is not caught precisely enough ##################
    # the chose configurations where enough for our experiments, but could be extended if needed. 

    if task == ('blue_cube', 'above', 0.03):      
        if b == 0:
            pos = np.array([0.17, 0.20, 0.146])
            obj1 = np.array([0.20, 0.20, 0.02])
            obj2 = np.array([0.20, 0.20, 0.04])   # 0.15, 0.20, 0.02
            obj3 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 1:
            pos = np.array([0.17, 0.20, 0.146])
            obj1 = np.array([0.20, 0.20, 0.02])
            obj3 = np.array([0.20, 0.20, 0.04]) 
            obj2 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 2:
            pos = np.array([0.17, 0.20, 0.146])
            obj1 = np.array([0.20, 0.20, 0.02])
            obj4 = np.array([0.20, 0.20, 0.04]) 
            obj3 = np.array([-0.1, -0.2, 0.02])
            obj2 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)


    if task == ('green_cube', 'above', 0.03):
        if b == 0:
            pos = np.array([0.17, 0.20, 0.146])
            obj2 = np.array([0.20, 0.20, 0.02])
            obj1 = np.array([0.20, 0.20, 0.04]) 
            obj3 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 1:
            pos = np.array([0.17, 0.20, 0.146])
            obj2 = np.array([0.20, 0.20, 0.02])
            obj3 = np.array([0.20, 0.20, 0.04])
            obj1 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 2:
            pos = np.array([0.17, 0.20, 0.146])
            obj2 = np.array([0.20, 0.20, 0.02])
            obj4 = np.array([0.20, 0.20, 0.04])
            obj3 = np.array([-0.1, -0.2, 0.02])
            obj1 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)


    if task == ('orange_cube', 'above', 0.03):
        if b == 0:
            pos = np.array([0.17, 0.20, 0.146])
            obj3 = np.array([0.20, 0.20, 0.02])
            obj2 = np.array([0.20, 0.20, 0.04])
            obj1 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 1:
            pos = np.array([0.17, 0.20, 0.146])
            obj3 = np.array([0.20, 0.20, 0.02])
            obj1 = np.array([0.20, 0.20, 0.04])
            obj2 = np.array([-0.1, -0.2, 0.02])
            obj4 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 2:
            pos = np.array([0.17, 0.20, 0.146])
            obj3 = np.array([0.20, 0.20, 0.02])
            obj4 = np.array([0.20, 0.20, 0.04]) 
            obj1 = np.array([-0.1, -0.2, 0.02])
            obj2 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)


    if task == ('red_cube', 'above', 0.03):
        if b == 0:
            pos = np.array([0.17, 0.20, 0.146])
            obj4 = np.array([0.20, 0.20, 0.02])
            obj2 = np.array([0.20, 0.20, 0.04]) 
            obj1 = np.array([-0.1, -0.2, 0.02])
            obj3 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 1:
            pos = np.array([0.17, 0.20, 0.146])
            obj4 = np.array([0.20, 0.20, 0.02])
            obj1 = np.array([0.20, 0.20, 0.04]) 
            obj2 = np.array([-0.1, -0.2, 0.02])
            obj3 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)

        if b == 2:
            pos = np.array([0.17, 0.20, 0.146])
            obj4 = np.array([0.20, 0.20, 0.02])
            obj3 = np.array([0.20, 0.20, 0.04])
            obj1 = np.array([-0.1, -0.2, 0.02])
            obj2 = np.array([-0.2, -0.2, 0.02])
            observation = build_observation(pos,obj1,obj2,obj3,obj4)
            env = set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4)


    environment = [observation,env]

    return environment



def flatten(observation):
  return np.concatenate([observation['robot'], observation['blue_cube']['position'],
                              observation['green_cube']['position'],
                              observation['orange_cube']['position'],
                              observation['red_cube']['position'], np.ones(1)])



def get_cost(task,dx):
    (anchor, relative_pos, distance_to_anchor)=task
    G = np.zeros((6, dx))

    m = 3
      #set anchor position
    G[:3,:3] = np.eye(3)*m
    block_dict = {'blue_cube': 0,'green_cube':1, 'orange_cube':2, 'red_cube':3}
    block_number = block_dict[anchor]
    G[:3,(10+3*block_number):(13+3*block_number)] = -np.eye(3)*m

    #set reference
    if relative_pos == 'right of':
        G[:3, -1] =  -m*np.array([0, -distance_to_anchor, 0.02])
    elif relative_pos == 'left of':
        G[:3, -1] =  -m*np.array([0, distance_to_anchor, 0.02])
    elif relative_pos == 'in front of':
        G[:3, -1] =  -m*np.array([distance_to_anchor, 0, 0.00])
    elif relative_pos == 'behind':
        G[:3, -1] =  -m*np.array([-distance_to_anchor, 0, 0.00])
    elif relative_pos == 'above':
        G[:3, -1] =  -m*np.array([0, 0, distance_to_anchor])

    G[3:,6:9] = 1*np.eye(3)*m

    return G

    

# define a function that transforms G^T@G according to the above feature vector

def G_to_linear_parameter_vector(G,dx,du):
    G_sqr = G.T@G
    param_vec = np.diag(G_sqr)
    for i in range(dx-1):
        param_vec = np.append(param_vec,2*G_sqr[i,i+1:])

    param_vec = np.append(param_vec,np.zeros(du))
    return param_vec


def build_observation(pos,obj1,obj2,obj3,obj4):
    observation = np.hstack([pos,np.zeros(7),obj1,obj2,obj3,obj4,1])
    return observation


def mpc_casadi(G,x0,horizon,dx,du):

    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = DM(A[:n,:n])
    B = DM(B[:n])

    N = horizon

    #define symbolic varibles
    x_sym = SX.sym('x_sym',dx,N+1)
    u_sym = SX.sym('u_sym',du,N)

    # build feature vector to learn
    feature = x_sym[:,0:N]*x_sym[:,0:N]
    for i in range(dx):
        for j in range(dx-1-i):
            feature = vertcat(feature,x_sym[i,0:N]*x_sym[i+1+j,0:N])

    feature = vertcat(feature,u_sym[:,0:N]*u_sym[:,0:N])

    #solver parameters
    options = {}
    options['ipopt.max_iter'] = 20000
    options['verbose'] = False
    options['ipopt.print_level'] = 0

    dyn = reshape(horzcat((x_sym[:,0] - x0), (x_sym[:,1:N+1] - A@x_sym[:,0:N] - B@u_sym[:,0:N])),(dx*(N+1),1))
    obstacle1 = sum1((x_sym[0:3,0:N+1] - x_sym[10:13,0:N+1])**2)
    obstacle2 = sum1((x_sym[0:3,0:N+1] - x_sym[13:16,0:N+1])**2)
    obstacle3 = sum1((x_sym[0:3,0:N+1] - x_sym[16:19,0:N+1])**2)
    obstacle4 = sum1((x_sym[0:3,0:N+1] - x_sym[19:22,0:N+1])**2)

    # define symbolic variables for cost parameters
    q_sub = G_to_linear_parameter_vector(G, dx, du)

    q = SX.sym('q',(feature.size(1),1))

    l = sum2(transpose(q)@feature)

    dl = substitute(l,q,q_sub)

    # set constraints with sqrt(0.0014) radius (increase this if you want to increase safety margin - done for hardware)
    const = vertcat(dyn,transpose(obstacle1),transpose(obstacle2),transpose(obstacle3),transpose(obstacle4),transpose(u_sym[0,:]),transpose(u_sym[1,:]),transpose(u_sym[2,:]))
    lbg = np.r_[np.zeros((dx)*(N+1)), 0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),-0.2*np.ones((N)),-0.2*np.ones((N)),-0.2*np.ones((N))]
    ubg = np.r_[np.zeros(dx*(N+1)), np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),0.2*np.ones((N)),0.2*np.ones((N)),0.2*np.ones((N))]

    lbx = -np.inf * np.ones(dx*(N+1)+du*N)
    ubx = np.inf * np.ones(dx*(N+1)+du*N)


    x = vertcat(reshape(x_sym[:,0:N+1],(dx*(N+1),1)),reshape(u_sym[:,0:N],(du*N,1)))

    # define solver
    nlp = {'x':x,'f':dl, 'g':const}
    solver = nlpsol('solver','ipopt', nlp, options)

    # create solver input
    solver_input = {}
    solver_input['lbx'] = lbx
    solver_input['ubx'] = ubx
    solver_input['lbg'] = lbg
    solver_input['ubg'] = ubg

    # solve optimization problem
    solver_output = solver(**solver_input)

    # process ouput
    sol = solver_output['x']
    sol_evalf = np.squeeze(evalf(sol))
    u = sol_evalf[-du*N:]
    u_applied = u[0:3]

    # print solution
    return u_applied

def mpc_casadi_pred(G,x0,horizon,dx,du):

    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = DM(A[:n,:n])
    B = DM(B[:n])

    N = horizon

    #define symbolic varibles
    x_sym = SX.sym('x_sym',dx,N+1)
    u_sym = SX.sym('u_sym',du,N)

    # build feature vector to learn
    feature = x_sym[:,0:N]*x_sym[:,0:N]
    for i in range(dx):
        for j in range(dx-1-i):
            feature = vertcat(feature,x_sym[i,0:N]*x_sym[i+1+j,0:N])

    feature = vertcat(feature,u_sym[:,0:N]*u_sym[:,0:N])

    #solver parameters
    options = {}
    options['ipopt.max_iter'] = 20000
    options['verbose'] = False
    options['ipopt.print_level'] = 0

    dyn = reshape(horzcat((x_sym[:,0] - x0), (x_sym[:,1:N+1] - A@x_sym[:,0:N] - B@u_sym[:,0:N])),(dx*(N+1),1))
    obstacle1 = sum1((x_sym[0:3,0:N+1] - x_sym[10:13,0:N+1])**2)
    obstacle2 = sum1((x_sym[0:3,0:N+1] - x_sym[13:16,0:N+1])**2)
    obstacle3 = sum1((x_sym[0:3,0:N+1] - x_sym[16:19,0:N+1])**2)
    obstacle4 = sum1((x_sym[0:3,0:N+1] - x_sym[19:22,0:N+1])**2)

    # define symbolic variables for cost parameters
    q_sub = G_to_linear_parameter_vector(G, dx, du)

    q = SX.sym('q',(feature.size(1),1))

    l = sum2(transpose(q)@feature)

    dl = substitute(l,q,q_sub)

    # set constraints with sqrt(0.0014) radius (increase this if you want to increase safety margin - done for hardware)
    const = vertcat(dyn,transpose(obstacle1),transpose(obstacle2),transpose(obstacle3),transpose(obstacle4),transpose(u_sym[0,:]),transpose(u_sym[1,:]),transpose(u_sym[2,:]))
    lbg = np.r_[np.zeros((dx)*(N+1)), 0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),0.0014*np.ones((N+1)),-0.2*np.ones((N)),-0.2*np.ones((N)),-0.2*np.ones((N))]
    ubg = np.r_[np.zeros(dx*(N+1)), np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),np.inf*np.ones((N+1)),0.2*np.ones((N)),0.2*np.ones((N)),0.2*np.ones((N))]

    lbx = -np.inf * np.ones(dx*(N+1)+du*N)
    ubx = np.inf * np.ones(dx*(N+1)+du*N)


    x = vertcat(reshape(x_sym[:,0:N+1],(dx*(N+1),1)),reshape(u_sym[:,0:N],(du*N,1)))

    # define solver
    nlp = {'x':x,'f':dl, 'g':const}
    solver = nlpsol('solver','ipopt', nlp, options)

    # create solver input
    solver_input = {}
    solver_input['lbx'] = lbx
    solver_input['ubx'] = ubx
    solver_input['lbg'] = lbg
    solver_input['ubg'] = ubg

    # solve optimization problem
    solver_output = solver(**solver_input)

    # process ouput
    sol = solver_output['x']
    sol_evalf = np.squeeze(evalf(sol))
    u = sol_evalf[-du*N:]
    u_applied = u[0:3]

    # print solution
    return sol_evalf


def get_action(observation, task, t, horizon, dx, du):

    if task == 'pick up block':
        if t < 10:
            action = np.array([0,0,-0.1,1.0])
        elif t < 11:
            action = np.array([0,0,0.0,-1.0])
        elif t < 50:
            action = np.array([0,0,0.1,-1.0])
        else:
            action = np.array([0,0,0.0,-1.0])
    elif task == 'release block':
        action = np.array([0,0,0.1,0.0])
    else:
        G = get_cost(task,dx)
        action = np.hstack([mpc_casadi(G, observation, horizon, dx, du), 0.0])
    return action

def get_prediction(observation, task, horizon, dx, du):

    G = get_cost(task,dx)
    sol = mpc_casadi_pred(G, observation, horizon, dx, du)
    x = sol[:-du*horizon]
    u = sol[-du*horizon:]
    x = x.reshape(horizon+1,dx)
    u = u.reshape(horizon,du)

    prediction = [x,u]

    return prediction

def get_receeding_horizon_lin(observation, task, horizon, dx, du):

    G = get_cost(task,dx)

    x_traj = np.zeros([horizon+1,dx])
    u_traj = np.zeros([horizon,du])

    x_traj[0,:] = observation

    t = 0

    for i in range(horizon):

        t = t+1

        sol = mpc_casadi_pred(G, observation, horizon, dx, du)
        x = sol[:-du*horizon]
        u = sol[-du*horizon:]
        x = x.reshape(horizon+1,dx)
        u = u.reshape(horizon,du)
        observation = x[1,:]
        x_traj[i+1,:] = observation
        u_traj[i,:] = u[0,:]

    prediction = [x_traj,u_traj]

    return prediction

def get_state_traj_to_input(x0,u):

    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = np.array(A[:n,:n])
    B = np.array(B[:n])

    length = np.shape(u)[1]
    traj_x = np.zeros([len(x0),length+1])

    traj_x[:,0] = x0

    for i in range(length):
        traj_x[:,i+1] = A@traj_x[:,i]+B@u[:,i]

    return traj_x

def get_state_traj_to_input_nonlin(x0,u):

    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = np.array(A[:n,:n])
    B = np.array(B[:n])

    length = np.shape(u)[1]
    traj_x = np.zeros([len(x0),length+1])

    traj_x[:,0] = x0

    for i in range(length):
        traj_x[:,i+1] = A@traj_x[:,i]+B@u[:,i]

    return traj_x

def get_input_to_state_transition(x1,x2):

    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = np.array(A[:n,:n])
    B = np.array(B[:n])

    x_diff = x2 - A@x1
    u = np.linalg.inv(B[:3,:3])@x_diff[:3]

    return u

def set_position_in_panda_gym(pos,obj1,obj2,obj3,obj4):

    env = gym.make("PandaCubes-v2") 
    observation = env.reset()

    order = ['blue_cube', 'green_cube', 'orange_cube', 'red_cube']

    env.env.env.sim.set_base_pose(order[0], obj1, np.zeros(3))
    env.env.env.sim.set_base_pose(order[1], obj2, np.zeros(3))
    env.env.env.sim.set_base_pose(order[2], obj3, np.zeros(3))
    env.env.env.sim.set_base_pose(order[3], obj4, np.zeros(3))


    joint_angles = env.env.env.robots[0].inverse_kinematics(8, pos, np.array([0.0, 0.0, 0.0]))
    env.env.env.robots[0].set_joint_angles(joint_angles)

    return env


def get_receeding_horizon(env, task, horizon, length, dx, du):

    observation, _, _, _ = env.step([np.zeros(6)])
    observation = flatten(observation)
    #print('observation:', observation)

    x_traj = np.zeros([length+1,dx])
    x_traj_lin = np.zeros([length+1,dx])
    u_traj = np.zeros([length,du])

    x_traj[0,:] = observation
    x_traj_lin[0,:] = observation

    t = 0

    for i in range(length):

        t = t+1

        action = get_action(observation, task, t, horizon, dx, du)
        rotation_action = np.zeros(3)
        observation, _, _, _ = env.step([np.concatenate((action,rotation_action))])
        observation = flatten(observation)
        x_traj[i+1,:] = observation
        x_traj_lin[i+1,:] = get_state_traj_to_input(x_traj[i,:],action[:3].reshape(-1,1))[:,1]
        u_traj[i,:] = action[:3]

    prediction = [x_traj,u_traj,x_traj_lin]

    return prediction



def return_infeasible_traj(G,num_samples, traj_x, traj_u, length, dx, du, thetas):

    # Adjust these parameters in case you find no unsafe trajectory samples 
    np.random.seed(1)
    std_dev = 0.01      # standard deviation of guassian noise on input
    max_iter = 10000    # number of input samples it checks for cost decrease
    max_unsafe = 2
    cost_buffer = 0.005*(10**8) # cost buffer to avoid dectections due to numerical precision issues

    N = length
    length_u = length-1

    #load linearized dynamics
    n = 23
    with open('ls_model.pkl', 'rb') as f:
	       (A,B) = pickle.load(f)

    A = np.array(A[:n,:n])
    B = np.array(B[:n])

    # use casadi to construct cost
    # define symbolic varibles
    x_sym = SX.sym('x_sym',dx,N)
    u_sym = SX.sym('u_sym',du,N)

    # estimated cost  
    x_sym_est = SX.sym('x_sym_est',dx+2,N)
    u_sym_est = SX.sym('u_sym_est',du,N)

    traj_x_est = np.concatenate((traj_x[:-1,:],np.zeros((2,N)),np.reshape(traj_x[-1:,:],(1,N))),axis=0)

    # build feature vector to learn (actual cost)
    feature = x_sym[:,0:N]*x_sym[:,0:N]
    for i in range(dx):
        for j in range(dx-1-i):
            feature = vertcat(feature,x_sym[i,0:N]*x_sym[i+1+j,0:N])

    feature = vertcat(feature,u_sym[:,0:N]*u_sym[:,0:N])

    # define symbolic variables for cost parameters (actual cost)
    q_sub = G_to_linear_parameter_vector(G, dx, du)

    q = SX.sym('q',(feature.size(1),1))
    l = sum2(transpose(q)@feature)
    dl = substitute(l,q,q_sub)

    # build feature vector to learn (learned cost)
    feature_est = x_sym_est[:,0:N]*x_sym_est[:,0:N]
    for i in range(dx+2):
        for j in range(dx+2-1-i):
            feature_est = vertcat(feature_est,x_sym_est[i,0:N]*x_sym_est[i+1+j,0:N])

    feature_est = vertcat(feature_est,u_sym_est[:,0:N]*u_sym_est[:,0:N])

    # define symbolic variables for cost parameters (actual cost)
    q_sub_est = G_to_linear_parameter_vector(thetas, dx+2, du)

    q_est = SX.sym('q_est',(feature_est.size(1),1))
    l_est = sum2(transpose(q_est)@feature_est)
    cost_est = substitute(l_est,q_est,q_sub_est)

    obstacle1 = sum1((x_sym[0:3,0:N] - x_sym[10:13,0:N])**2)
    obstacle2 = sum1((x_sym[0:3,0:N] - x_sym[13:16,0:N])**2)
    obstacle3 = sum1((x_sym[0:3,0:N] - x_sym[16:19,0:N])**2)
    obstacle4 = sum1((x_sym[0:3,0:N] - x_sym[19:22,0:N])**2)

    # check the cost value (actual and learned cost given demonstration)
    cost_opt = substitute(substitute(dl,x_sym,traj_x),u_sym,traj_u)
    cost_opt_est = substitute(substitute(cost_est,x_sym_est,traj_x_est),u_sym_est,traj_u)

    # sample the the potentially infeasible trajectories
    samples = np.zeros([num_samples,dx,length])
    # first dimension is filled with feasible optimal traj
    samples[0,:,:] = traj_x
    #print("traj_x:", traj_x[:3,-1])
    #print("traj_u:", traj_u[:3,-2])
    num_unsafe = 0
    for s in range(1,num_samples):
        tot_tries = 0
        failed = 0
        while 1:
            # to avoid linearization errors, we only vary the last state of the trajectory section, which is equal to vary the last input
            # but like this we do not have to pass it to the system again and recall the environment. 
            traj_prop = np.array(traj_x)
            traj_prop[:3,-1] = traj_prop[:3,-1] + np.vstack([std_dev*(2*np.random.rand()-1),0.0*np.random.rand(),std_dev*(2*np.random.rand()-1)]).reshape(3)
            traj_prop_est = np.concatenate((traj_prop[:-1,:],np.zeros((2,N)),np.reshape(traj_prop[-1:,:],(1,N))),axis=0)
            #print("traj_prop:", traj_prop[:3,-1])
            u_altered = get_input_to_state_transition(traj_prop[:,-2],traj_prop[:,-1])
            u_prop = traj_u
            #u_prop[:,-2] = u_altered
            # print("traj_u:", traj_u[:3,-2])
            # print("u_altered:", u_altered)
            cost_prop = substitute(substitute(dl,x_sym,traj_prop),u_sym,u_prop)
            cost_prop_est = substitute(substitute(cost_est,x_sym_est,traj_prop_est),u_sym_est,u_prop)
            #print("cost_opt:", cost_opt)
            #print("cost_prop:", cost_prop)

            if (cost_prop_est < (cost_opt_est-cost_buffer) and np.max(u_altered)< 0.2001):
                print("unsafe sample")
                samples[s,:,:] = traj_prop
                print(traj_prop[:3,:])
                print(traj_x[:3,:])
                const_value1 = evalf(substitute(obstacle1,x_sym,traj_prop))
                const_opt1 = evalf(substitute(obstacle1,x_sym,traj_x))
                const_value2 = evalf(substitute(obstacle2,x_sym,traj_prop))
                const_opt2 = evalf(substitute(obstacle2,x_sym,traj_x))
                const_value3 = evalf(substitute(obstacle3,x_sym,traj_prop))
                const_opt3 = evalf(substitute(obstacle3,x_sym,traj_x))
                const_value4 = evalf(substitute(obstacle4,x_sym,traj_prop))
                const_opt4 = evalf(substitute(obstacle4,x_sym,traj_x))
                print(const_value1)
                print(const_opt1)
                print(const_value2)
                print(const_opt2)
                print(const_value3)
                print(const_opt3)
                print(const_value4)
                print(const_opt4)
                print(evalf(cost_prop))
                print(evalf(cost_opt))
                print(evalf(cost_prop_est))
                print(evalf(cost_opt_est))
                num_unsafe = num_unsafe + 1
                break
            if (tot_tries > max_iter):
                failed = 1
                print("failed")
                break

            tot_tries = tot_tries + 1

        if failed:
            break

        if (num_unsafe > max_unsafe):
            print("max num unsafe")
            break

    sample_info = [samples, s-1, N]

    return sample_info



if __name__ == "__main__":
    np.random.seed(0)
    solver_problem_main()
