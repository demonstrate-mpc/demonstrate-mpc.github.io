README:

Dependencies:
-------------
- numpy
- os
- sys
- Safe Panda Gym (download folder from https://github.com/vateseif/Safe-panda-gym.git@safe_rl-panda-gym)
- Casadi
- Ipopt
- Satex solver, which requires CPLEX and CPLEX Pyton API 

Satex solver, CPLEX. and CPLEX Pyton API:
--------------
- To run "learn_from_safe_traj.py" you need to employ SatEX: Satisfiability modulo convEX optimization solver, which requires CPLEX and CPLEX Pyton API. Instructions are available under: https://yshoukry.bitbucket.io/SatEX/downloads.html. Students licence available.
- You further need casadi installed: https://web.casadi.org/docs/.

Run code:
------------------
- To get the matrix H, indicating which constraints are required with binary variables (1 for required and 0 for not required), as well as a vector with the radi, denoted with R, you need to run the file "learn_from_safe_traj.py". The values are stored in params_c. 


Sharing and access information:
----------------------------------

Copyright (c) 2025 ETH Zurich, Rahel Rickenbach, Bruce Lee, René Zurbrügg, Carmen Amo Alonso, Prof. Melanie N. Zeilinger, Institute for Dynamics Systems and Control. No rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

